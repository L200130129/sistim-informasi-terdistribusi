<?php

$list = array("list" => array(
	"eggs",
	"bread",
	"milk",
	"bananas",
	"bacon",
	"cheese"
));

echo json_encode($list);
