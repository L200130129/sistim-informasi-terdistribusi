<?php

echo "This request made by: " . $_SERVER['HTTP_USER_AGENT'];
