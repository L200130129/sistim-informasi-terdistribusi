PHP-Web-Services
================

The book: [PHP Web Services on OReilly.com](http://www.dpbolvw.net/click-7049572-11260198?url=http%3A%2F%2Fshop.oreilly.com%2Fproduct%2F0636920028291.do%3Fcmp%3Daf-prog-book-product_cj_9781449356569_%25zp&cjsku=0636920028291) (affiliate link)

Collection of PHP code samples to accompany the PHP Web Services book (authored by Lorna Jane Mitchell, published by O'Reilly).  Feel free to fork and use for inspiration, this is quite literally the contents of my working code folders as I developed the book itself.  They are mostly trivial, and I offer no guarantee as to their usefulness, but you are more than welcome to them :)

(if you're looking for the code samples for the 1st edition of the book, use the `1st-edition` branch)
